#include <stdio.h>

int main(){
    int i = 1;
    while (i == 1){
        i++;
        i--;
    }
}

// ./l & ./l & ./l & ./l & ./l & ./experim2